<?php
$userId             = getArrayValue($userInfo, "id");
$username           = getArrayValue($userInfo, "username");
$password           = getArrayValue($userInfo, "password");
$email              = getArrayValue($userInfo, "email");
$mobile             = getArrayValue($userInfo, "mobile");
$traffic            = getArrayValue($userInfo, "format_traffic");
$startDate          = getArrayValue($userInfo, "start_date");
$endDate            = getArrayValue($userInfo, "end_date");
$expiryDays         = getArrayValue($userInfo, "expiry_days");
$expiryType         = getArrayValue($userInfo, "expiry_type");
$mobilebrand        = getArrayValue($userInfo, "mobilebrand");
$operator           = getArrayValue($userInfo, "operator");
$useruuid           = getArrayValue($userInfo, "useruuid");
$usersinfo          = getArrayValue($userInfo, "usersinfo");
$desc               = getArrayValue($userInfo, "desc");
$concurrentUsers    = getArrayValue($userInfo, "limit_users");
$consumerTraffic    = getArrayValue($userInfo, "format_consumer_traffic");
$endDateJD          = getArrayValue($userInfo, "end_date_jd"); //jalali date
$startJD            = getArrayValue($userInfo, "start_date_jd"); //jalali date
$remainingDays      = getArrayValue($userInfo, "remaining_days", 0);
$netmodQrUrl        = getArrayValue($userInfo, "netmod_qr_url", "");
$status             = getArrayValue($userInfo, "status", "");
$arrayConfig        = getArrayValue($userInfo, "array_config", []);
$diffrenceDate      = getArrayValue($userInfo, "diffrence_date", "");
$sshPort            = getArrayValue($arrayConfig, "ssh_port", "");
$udpPort            = getArrayValue($arrayConfig, "udp_port", "");
$host               = getArrayValue($arrayConfig, "host", "");

$remainingText = "";
if ($remainingDays >= 0) {
    $remainingText = "$remainingDays روز";
} else if ($remainingDays < 0) {
    $remainingText = "<span class='text-danger'>" . abs($remainingDays) . " روز گذشته</span>";
}





$sousername = "Net-" . ucfirst($username);


$sohost  = '';
if ($operator == 'HamrahAval'){
	$sohost = 'mci.cloudns.cl';
} elseif ($operator == 'Irancell') {
	$sohost = 'mtn.cloudns.cl';
} 

$mobileiphone  = '';
$mobileandroid = '';
if ($mobilebrand == 'iPhone'){
	$mobileiphone   = ' style="display:block!important"';
	$mobileandroid  = ' style="display:none!important"';
} elseif ($mobilebrand == 'Android') {
	$mobileandroid = ' style="display:block!important"';
	$mobileiphone  = ' style="display:none!important"';
} 




$values = [
	[
        "label" => "Ssh",
        "value" => "<span class='cursor-pointer' data-copy='true' data-text='$sousername' data-bs-toggle='tooltip' title='کپی شد'>$sousername<i class='far fa-copy btn-copy-config btn-float-icon btn-copy-config'></i></span>",
    ],
    [
        "label" => "ترافیک مصرفی",
        "value" => $consumerTraffic ? "<span id='spn-user-traffic'>$consumerTraffic</span>" : 0
    ],
    [
        "label" => "زمان باقی مانده",
        "value" => $remainingText,
    ],
    [
        "label" => "تعداد کاربران",
        "value" => $concurrentUsers,
    ],
	[
        "label" => "مدل گوشی",
        "value" => $mobilebrand,
    ],
	[
        "label" => "سیمکارت",
        "value" => $operator,
    ],
];

?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-lg border-0">
            <div class="card-header border-bottom-0 py-3" rtl>
				<img class="mb-4 sologo" src="<?= baseUrl("assets/images/logo.png") ?>" width="72">
				اطلاعات پروفایل
				<a class="btn btn-danger mt-2 d-block so-exit" href="<?= baseUrl("") ?>">خروج</a>
			</div>
			<div class="card-body">
                <?php if (!empty($settings["logo_url"])) { ?>
                    <div class="text-center">
                        <img src="<?= $settings["logo_url"] ?>" width="100" />
                    </div>
                <?php } ?>
                <?php if (!empty($settings["welecom_text"])) { ?>
                    <div class="text-center border-bottom py-2"><?= $settings["welecom_text"] ?></div>
                <?php } ?>
                <div class="row">
                    <div class="col-lg-8 border-end">
						<?php $class = "d-flex flex-row align-items-center justify-content-between py-2 px-3"; ?>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">Ssh</span>
								<span id="matna3" class="fw-bold" onclick="copyToClipboard('#matna3')" title="کپی"><?= $sousername ?><i class="far fa-copy btn-copy-config btn-float-icon"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Host</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna4"><?= $sohost ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna4')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Port</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna5"><?= $sshPort ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna5')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">UDP Port</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna6"><?= $udpPort ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna6')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Username</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna7"><?= $username ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna7')"></i></span>
							</div>
							<div class="<?= $class ?> border-bottom">
                                <span class="text-muted small">SSH Password</span>
								<span class=" fw-bold"><p class="so-widt fw-bold" id="matna8"><?= $password ?></p><i class="far fa-copy btn-copy-config btn-float-icon btn-copy-config" onclick="copyToClipboard('#matna8')"></i></span>
							</div>
							
						<?php

                        foreach ($values as  $key => $item) {
                            $label = $item["label"];
                            $value = $item["value"];
                            $class = "d-flex flex-row align-items-center justify-content-between py-2 px-3 border-bottom";
                        ?>
                            <div class="<?= $class ?> border-bottom">
                                <span class="text-muted small"><?= $label ?></span>
                                <span class=" fw-bold"><?= $value ? $value : "-" ?></span>
                            </div>
                        <?php
                        }
                        ?>
						<div class="d-flex flex-row align-items-center justify-content-between py-2 px-3 so-topboarder so-bt">
							<div class="so-align mohidde" <?= $mobileiphone ?>>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">دانلود برنامه ها</span>
								<div class="so-softiconbox">
									<a target="_blank" class="so-softicons" href="<?= baseUrl("https://apps.apple.com/gb/app/npv-tunnel/id1629465476") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/NapsternetV.png") ?>" width="72"><span class="text-muted so-info so-widt so-softicontitle">NapsternetV</span></a>
									<a target="_blank" class="so-softicons" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width='72'><span class="text-muted so-info so-widt so-softicontitle">Streisand</span></a>
								</div>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">راهنمای تنظیم اکانتها در آیفون</span>
								<div class="so-align-img">
									<!--div class="so-sovideos">
										<video controls poster="<?= baseUrl("assets/images/VideoNapsternetVPooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/1.mp4") ?>" type="video/mp4">
										</video>
									</div-->
									<div class="so-sovideos">
										<video controls poster="<?= baseUrl("assets/images/VideoStreisandPooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/Streisand in IOS.mp4") ?>" type="video/mp4">
										</video>
									</div>
								</div>
							</div>
							<div class="so-align mohidde" <?= $mobileandroid ?>>
								<span class="text-muted fw-bold so-info so-widt so-topboarder">راهنمای تنظیم اکانتها در اندروید</span>
								<div class="so-align-img">
									<div class="so-sovideos">
										<a target="_blank" class="so-softicons" href="<?= baseUrl("assets/images/HiddifyNG_armeabi-v7a.apk") ?>"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/HiddifyNG.png") ?>" width="72"></a>
										<video controls poster="" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/1.mp4") ?>" type="video/mp4">
										</video>
									</div>
									<div class="so-sovideos">
										<a target="_blank" class="so-softicons" href="https://apps.apple.com/us/app/streisand/id6450534064"><img class="mb-4 so-img" src="<?= baseUrl("assets/images/Streisand.png") ?>" width="72"></a>
										<video controls poster="<?= baseUrl("assets/images/VideoiPhonePooster.png") ?>" controlsList="nodownload">
											<source src="<?= baseUrl("assets/videos/Streisand in IOS.mp4") ?>" type="video/mp4">
										</video>
									</div>
								</div>
							</div>
							<div class="so-iconsbox">
								<div class="so-btns so-btns-ssh">
									<button class="btn btn-primary w-100 py-2 so-btn-st" onclick="copyToClipboard('#matna1')">لینک v2Ray<p class="so-widt" id="matna1">https://panel.cloudns.cl:2087/sub/<?= $usersinfo ?></p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st" onclick="copyToClipboard('#matna2')">لینک SSH<p class="so-widt" id="matna2">ssh://<?= $username ?>:<?= $password ?>@<?= $host ?>:<?= $sshPort ?>#net-<?= ucfirst($username); ?></p></button>	
								</div>
								<div class="so-btns so-btns-vray">
									<!--?= print_r($jsonfilee) ?-->
									<!--?= $userUUID ?-->
									<!--?= var_dump($userUUID) ?-->
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna10')">HamrahAval<p class="so-widt so-widt-vray" id="matna10" style="font-size:0!important;width:100px!important;">vless://<?= $useruuid ?>@xmci.cloudns.cl:443?type=tcp&serviceName=%40net&security=none&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=panel.cloudns.cl#net-<?= ucfirst($username); ?>  HamrahAval</p></button>
									<button class="btn btn-primary w-100 py-2 so-btn-st so-btn-st-vray" style="padding:8px 4px 2px 4px!important;font-size:13px;max-width:100px!important" onclick="copyToClipboard('#matna11')">Irancell<p class="so-widt so-widt-vray" id="matna11" style="font-size:0!important;width:100px!important;">vless://<?= $useruuid ?>@xmtncloudns.cl:443?type=tcp&serviceName=%40net&security=none&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=panel.cloudns.cl#net-<?= ucfirst($username); ?>  Irancell</p></button>
								</div>	
								<div class="so-textBoxpanel">
									<span class="text-muted fw-bold so-info so-widt so-topboarder so-textBoxTitr">اخبار</span>
									<div class="so-textBox">
										...
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>