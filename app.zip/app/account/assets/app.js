function copyToClipboard(element) {
	var $temp = $("<input>");
	const tooltip = document.querySelector(element);
	$("body").append($temp);
	$temp.val($(element).text()).select();
	document.execCommand("copy");
	$temp.remove();
	tooltip.setAttribute("title", "کپی شد");
	//alert('کپی شد');
}