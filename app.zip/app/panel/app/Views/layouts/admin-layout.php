<?php include "sections/head.php"; ?>

	<?php include "sections/sidemenu.php"; ?>
	<label id="btnContent" title="کاربران آنلاین" class="btnContent btn-open">
		<h5 class="card-dash-h5"><?= userOnlineCounter() ?></h5>
	</label> 
	<div class="content navi-close">
		<div class="naviCover"></div>

		<?php include viewContentPath($viewContent); ?>
		
	</div>
	
<?php include "sections/footer.php"; ?>