<div id="swiper-pack" class="swiper-pack">
	<div class="arrow arrow-left"></div>
	<div class="arrow arrow-right"></div>
	<swiper-container class="mySwiper" space-between="30" loop="true">
		<swiper-slide style="padding:0 5px">
			<div class="card-dash-info dash-card-a slide">
				<div>
					<h6 class="card-dash-h6">آنلاین</h6>
					<a class="Counter" href="<?= baseUrl("users/online") ?>">
						<h5 class="card-dash-h5"><?= userOnlineCounter() ?></h5>
					</a>
				</div>
				<div>
					<h6 class="card-dash-h6">کاربران</h6>
					<a href="<?= baseUrl("users") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["all"] ?></h5>
					</a>
				</div>
				<div>
					<h6 class="card-dash-h6">فعال</h6>
					<a href="<?= baseUrl("users?status=active") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["active"] ?></h5>
					</a>
				</div>
				<div>
					<h6 class="card-dash-h6">غیر فعال</h6>
					<a href="<?= baseUrl("users?status=de_active") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["inActive"] ?></h5>
					</a>
				</div>
				<div>
					<h6 class="card-dash-h6">اتمام ترافیک</h6>
					<a href="<?= baseUrl("users?status=expiry_traffic") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["expiryTraffic"] ?></h5>
					</a>
				</div>
				<div>
					<h6 class="card-dash-h6">انقضای تاریخ</h6>
					<a href="<?= baseUrl("users?status=expiry_date") ?>">
						<h5 class="card-dash-h5"><?= $totalData["users"]["expiryDate"] ?></h5>
					</a>
				</div>
			</div>	
		</swiper-slide>
		<swiper-slide style="padding:0 5px">
			<div class="card-dash-info dash-card-b slide">
				<div>
					<h6 class="card-dash-h6">IP v4</h6>
					<h5 class="card-dash-h5"><?= getServerIp() ?></h5>
				</div>
				<div>
					<h6 class="card-dash-h6">IP v6</h6>
					<h5 class="card-dash-h5"><?= getServerIpV6() ?></h5>
				</div>
				<div>
					<h6 class="card-dash-h6">IP Login</h6>
					<h5 class="card-dash-h5"><?= userIPAddress() ?></h5>
				</div>
				<div>
					<h6 class="card-dash-h6">Domain</h6>
					<h5 class="card-dash-h5"><?= getServerName() ?></h5>
				</div>
				<div>
					<h6 class="card-dash-h6">SSH Port</h6>
					<h5 class="card-dash-h5"><?= getenv("PORT_SSH"); ?></h5>
				</div>
				<div>
					<h6 class="card-dash-h6">UDP Port</h6>
					<h5 class="card-dash-h5"><?= getenv("PORT_UDP"); ?></h5>
				</div>
			</div>	
		</swiper-slide>	
		<swiper-slide style="padding:0 5px">
			<div class="card-dash-info dash-card-d slide">
				<div class="so-card card">
					<h6 class="small">امروز : <?= getCurrentDate() ?></h6>
				</div>
				<div class="so-card card">
					<h6 class="widget-title mb-3">ترافیک سرور</h6>
					<div class="so-card-t-total"><?= $serverTraffic["total"] ?></div>
				</div>
				<div class="so-card-t so-card">
					<div class="so-card-t-small-g so-card card">
						<small title="دانلود" class="so-card-doewn so-card-small"><p>&#11205;</p><?= $serverTraffic["download"] ?></small>
						<small title="آپلود" class="so-card-up so-card-small"><p>&#11206;</p><?= $serverTraffic["upload"] ?></small>
					</div>
				</div>
				<div class="so-card cardt">
					<h6 class="widget-title-footer small">ترافیک کاربران</h6>
					<div class="so-card-t-total"><?= $userTraffic["total"] ?></div>
				</div>
				<div class="so-card-t so-card card">
					<div class="so-card-t-small-g so-card card">
						<small title="دانلود" class="so-card-doewn so-card-small"><p>&#11205;</p><?= $userTraffic["download"] ?></small>
						<small title="آپلود" class="so-card-up so-card-small"><p>&#11206;</p><?= $userTraffic["upload"] ?></small>
					</div>
				</div>
				<div class="so-card-t so-card card">
					<h6 class="small">آپ تایم سرور :<?= $uptime ?></h6>
					<button title="ریبوت سیستم عامل" aria-label="کپی رمز" class="btn btn-Square btn-Square-normal btn-delete btn-reboot-server">
						<i class="fa fa.power-off"></i>
					</button>
				</div>
			</div>	
		</swiper-slide>	
	</swiper-container>
</div>
