<div class="card-header-user card-header-user">
	<form id="filtering-form">
		<div class="row">
			<div class="col-lg-2 col-lg-2-user">
				<div class="form-group mb-1 form-group-mobile">
					<input type="search" name="main_search" class="form-control form-control-user" placeholder="جستجو..." />
				</div>
			</div>
		</div>
	</form>
	<div class="actions actions-user">
		<button id="btnAddUser" class="btn btn-Square-normal btn-ajax-views btn-normal-margin net-btn-pc btn-Square-pc" data-url="users/add" style="margin-right:5px">
			کاربر جدید
		</button>
		<button class="btn btn-Square-normal btn-ajax-views btn-normal-margin net-btn-pc btn-Square-pc" data-url="users/bulk-add" style="margin-right:5px">
			کاربران جدید
		</button>
		<button class="btn btn-Square btn-Square-normal btn-ajax-views btn-normal-margin net-btn-mobile" data-url="users/add" style="margin-right:5px">
			<i class="fa fa-user-plus"></i>
		</button>
		<button class="btn btn-Square btn-Square-normal btn-ajax-views btn-normal-margin net-btn-mobile" data-url="users/bulk-add" style="margin-right:5px">
			<i class="fa fa-users-medical icon"></i>
		</button>
		<button class="btn btn-Square btn-delete btn-Square-normal btn-normal-margin" style="display:none;margin-right:5px;" id="btn-bulk-delete">
			<i class="fa fa-user-times"></i>
		</button>
	</div>
</div>
<table id="users-table" class="table" style="width: 100%;">
	<tbody>

	</tbody>
</table>
						
<div class="modal" tabindex="-1" id="renewal-users-modal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">تمدید کاربر</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<form id="renewal-users-form" method="put">
					<div class="form-group">
						<label>تعداد روزهای تمدید</label>
						<input type="number" name="renewal_days" class="form-control" min="1" placeholder="تعداد روزهای تمدید را وارد کنید" required>
					</div>
					<div class="row">
						<div class="col-lg-6">
							<div class="form-group">
								<label>ثبت از امروز</label>
								<div class="form-control">
									<div class="form-check form-check-inline mb-0">
										<input class="form-check-input" type="radio" name="renewal_date" value="yes" required>
										<label class="form-check-label  mb-0">بلی</label>
									</div>
									<div class="form-check form-check-inline mb-0">
										<input class="form-check-input" type="radio" checked name="renewal_date" value="no" required>
										<label class="form-check-label  mb-0">خیر</label>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<label>ریست کردن ترافیک</label>
								<div class="form-control">
									<div class="form-check form-check-inline mb-0">
										<input class="form-check-input" type="radio" name="renewal_traffic" value="yes" required>
										<label class="form-check-label  mb-0">بلی</label>
									</div>
									<div class="form-check form-check-inline mb-0">
										<input class="form-check-input" type="radio" checked name="renewal_traffic" value="no" required>
										<label class="form-check-label  mb-0">خیر</label>
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button class="btn btn-Square-normal btn-Square-pc" id="btn-submit-renewal" form='renewal-users-form'>
					ذخیره
				</button>
			</div>
		</div>
	</div>
</div>

<script>
	var activeStatus = "<?= $activeStatus ?>";
	var tablePageLength = 1000;
</script>