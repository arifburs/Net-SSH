<style>
    .table td {
        min-width: 80px;
    }
</style>
<div class="card">
    <div class="card-body table-responsive">
        <table id="online-users-table" class="table table-striped" style="width: 100%;">
            <thead>
                <tr>
                    <th width="40px">ردیف</th>
                    <th width="50%">نام کاربری</th>
                    <th width="40px">تعداد</th>
                    <th width="40%">آی پی</th>
                    <th width="40%">عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $num = 0;
                foreach ($onlineUsers as $username => $userData) {
                    $num++;
                    $pids = [];
                ?>
                    <tr>
                        <td width="40px"><?= $num ?></td>
                        <td width="50%"><?= $username ?></td>
                        <td width="40px">
                            <span class="badge p-2 text-bg-<?= count($userData) > 1 ? "danger" : "primary" ?>">
                                <?= count($userData) ?>
                            </span>
                        </td>
                        <td width="40%">
                            <div class="d-flex  flex-column m-auto">
                                <?php
                                foreach ($userData as $data) {
                                    $pids[] = $data["pid"];
                                ?>
                                    <div class="d-flex justify-content-between mb-1 align-items-center">
                                        <span><?= $data["ip"] ?></span>
                                        <button class="btn btn-danger btn-sm btn-kill-user btn-Square btn-Square-normal" data-pid="<?= $data["pid"] ?>">
                                            اخراج
                                        </button>
                                    </div>
                                <?php
                                }
                                ?>
                            </div>
                        </td>
                        <td class="td-allKill" width="40%">
                            <button class="btn btn-warning btn-kill-user btn-Square-normal" data-pid="<?= implode(",", $pids) ?>">
                                <i class="fa fa.users-slash"></i>
                                اخراج گروهی
                            </button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>