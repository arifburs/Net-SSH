<?php

/**
 * By a;i hassanzadeh
 * Github: https://github.com/ipmartnetwork
 */

namespace App\Controllers;

use \App\Libraries\UserShell;

class Pages extends BaseController
{

    public function filtering($request, $response, $args)
    {
		
		enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datepicker/datepicker.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));

        enqueueStyleHeader(assets("vendor/datepicker/datepicker.min.css"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));
		
		
        $this->data["activeMenu"]     = "filtering";

        $viewData = [];
        $viewData["pageTitle"]      = "وضعیت فیلترینگ";
        $viewData["viewContent"]    = "func/functions.php";
        $viewData["activePage"]     = "filtering";
		$viewData["activePage"]     = "dashboard";
		$viewData["activeMenu"]     = "users";
        $viewData["activePage"]     = "users";
		
		$uModel      = new \App\Models\Users();
        $tModel      = new \App\Models\Traffics();
        $userInfo    = $request->getAttribute('userInfo');
		$userRole    = $userInfo->role;
        $userName    = $userInfo->username;
		$adminRole   = getAdminRole();
        $onlineUsers = UserShell::onlineUsers();
		$accessUsers = $uModel->adminAccessUsers();
        

        $totalUsers                 = $uModel->totalUsers(null, $userRole, $userName);
        $totalActiveUsers           = $uModel->totalUsers("active", $userRole, $userName);
        $totalInActiveUsers         = $uModel->totalUsers("de_active", $userRole, $userName);
        $totalExpiryTrafficUsers    = $uModel->totalUsers("expiry_traffic", $userRole, $userName);
        $totalExpiryDateUsers       = $uModel->totalUsers("expiry_date", $userRole, $userName);

        $viewData["totalData"] = [
            "users" => [
                "all"               => $totalUsers,
                "active"            => $totalActiveUsers,
                "inActive"          => $totalInActiveUsers,
                "expiryTraffic"     => $totalExpiryTrafficUsers,
                "expiryDate"        => $totalExpiryDateUsers,
                "online"            => UserShell::totalOnlineUsers(),
            ],

        ];

        $viewData["ramData"]        = UserShell::ramData();
        $viewData["cpuData"]        = UserShell::cpuData();
        $viewData["diskData"]       = UserShell::diskData();
        $viewData["uptime"]         = UserShell::serverUptime();
        $viewData["serverTraffic"]  = UserShell::serverTraffic();
		    $viewData["userTraffic"]    = $tModel->totalData();
		    $viewData["onlineUsers"]    = $onlineUsers;
		
        $this->render($viewData);
	}
}
