<?php

/**
 * By ali hassanzadeh
 * Github: https://github.com/ipmartnetwork
 */

namespace App\Controllers;

use \App\Libraries\UserShell;


class Dashboard extends BaseController
{


    public function index($request, $response, $args)
    {
		enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datepicker/datepicker.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));

        enqueueStyleHeader(assets("vendor/datepicker/datepicker.min.css"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));
		
		    $status     = $request->getQueryParam("status");

        $viewData = [];
		$viewData["activeStatus"]   = $status;
        $viewData["pageTitle"]      = "داشبورد";
        $viewData["viewContent"]    = "dashboard.php";
		$viewData["activePage"]     = "dashboard";
		$viewData["activeMenu"]     = "dashboard";
		$viewData["activePage"]     = "users/online.php";
		$viewData["activePage"]     = "users/index.php";
        $viewData["activeMenu"]     = "users";
        $viewData["activePage"]     = "users";

        

        $uModel      = new \App\Models\Users();
        $tModel      = new \App\Models\Traffics();
        $userInfo    = $request->getAttribute('userInfo');
		$userRole    = $userInfo->role;
        $userName    = $userInfo->username;
        $onlineUsers = UserShell::onlineUsers();
		    $accessUsers = $uModel->adminAccessUsers();
        

        $totalUsers                 = $uModel->totalUsers(null, $userRole, $userName);
        $totalActiveUsers           = $uModel->totalUsers("active", $userRole, $userName);
        $totalInActiveUsers         = $uModel->totalUsers("de_active", $userRole, $userName);
        $totalExpiryTrafficUsers    = $uModel->totalUsers("expiry_traffic", $userRole, $userName);
        $totalExpiryDateUsers       = $uModel->totalUsers("expiry_date", $userRole, $userName);

        $viewData["totalData"] = [
            "users" => [
                "all"               => $totalUsers,
                "active"            => $totalActiveUsers,
                "inActive"          => $totalInActiveUsers,
                "expiryTraffic"     => $totalExpiryTrafficUsers,
                "expiryDate"        => $totalExpiryDateUsers,
                "online"            => UserShell::totalOnlineUsers(),
            ],

        ];
        $viewData["ramData"]        = UserShell::ramData();
        $viewData["cpuData"]        = UserShell::cpuData();
        $viewData["diskData"]       = UserShell::diskData();
        $viewData["uptime"]         = UserShell::serverUptime();
        $viewData["serverTraffic"]  = UserShell::serverTraffic();
        $viewData["userTraffic"]    = $tModel->totalData();
		    $viewData["onlineUsers"]    = $onlineUsers;

        $this->render($viewData);
    }
	
	public function online($request, $response, $args)
    {
		
		$uModel      = new \App\Models\Users();
        $accessUsers = $uModel->adminAccessUsers();
        $onlineUsers = UserShell::onlineUsers();
        $adminRole   = getAdminRole();

        if ($adminRole !== "admin") {
            if (!empty($accessUsers)) {
                foreach ($onlineUsers  as $username => $users) {
                    if (!in_array($username, $accessUsers)) {
                        unset($onlineUsers[$username]);
                    }
                }
            } else {
                $onlineUsers = [];
            }

            ksort($onlineUsers);
        }
		
	    $viewData = [];
        $viewData["activeMenu"]     = "online-users";
        $viewData["activePage"]     = "online-users";

        $this->render($viewData);
    }
	
	public function ajaxViewAdd($request, $response, $args)
    {
        $viewData = [];
        $viewData['activePage']   = 'users/form.php';
        return $this->renderAjxView($viewData);
    }

    public function ajaxViewBulkAdd($request, $response, $args)
    {
        $viewData = [];
        $viewData['activePage']   = 'users/bulk-form.php';
        return $this->renderAjxView($viewData);
    }

    public function ajaxViewEdit($request, $response, $args)
    {
        $editId     = $args["id"];
        $viewData   = [];

        $uModel     = new \App\Models\Users();
        $userInfo   = $uModel->getInfo($editId);

        if ($userInfo) {
            $viewData['userValues']    = $userInfo;
            $viewData['activePage']   = 'users/form.php';
            $viewData['refrence']      = $request->getQueryParam("ref");
            return $this->renderAjxView($viewData);
        } else {
            $viewData['activePage']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }

    public function ajaxViewDetails($request, $response, $args)
    {

        $editId     = $args["id"];
        $viewData   = [];

        $uModel     = new \App\Models\Users();
        $userInfo   = $uModel->getInfo($editId);
        if ($userInfo) {
            $viewData['userValues']    = $userInfo;
            $viewData['activePage']   = 'users/details.php';
            return $this->renderAjxView($viewData);
        } else {
            $viewData['activePage']   = 'notfound-modal.php';
        }
        return $this->renderAjxView($viewData);
    }

    public function ajaxAddUser($request, $response, $args)
    {
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Users::save($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uModel = new \App\Models\Users();
        try {
            $uModel->saveUsers($pdata, $uid);
        } catch (\Exception $err) {
            $result["status"] = "error";
            $result["messages"] = "در افزودن کاربر خطایی رخ داد. لطفا دوباره امتحان کنید";
            return $response->withStatus(400)->withJson($result);
        }
    }


    public function ajaxSaveRenewal($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Users::renewal($pdata, $editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uModel = new \App\Models\Users();
        $uModel->renewalUsers($pdata, $editId);
    }

    public function ajaxAddBulkUsers($request, $response, $args)
    {
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Users::bulkUsers($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uModel = new \App\Models\Users();
        $added = $uModel->createBulkUsers($pdata);
        if ($added) {
            $message = "تعداد $added کاربر با موفقیت افزوده شد";
            return $response->withStatus(200)->withJson(["messages" => $message]);
        }
        return $response->withStatus(400)->withJson(["messages" => "متاسفانه هیچ کاربری اضافه نشد"]);
    }

    public function ajaxEditUser($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Users::save($pdata, $editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uModel = new \App\Models\Users();
        try {
            $uModel->saveUsers($pdata, $uid, $editId);
        } catch (\Exception $err) {
            $result["status"] = "error";
            $result["messages"] = "در افزودن کاربر خطایی رخ داد. لطفا دوباره امتحان کنید";
            return $response->withStatus(400)->withJson($result);
        }
    }

    public function ajaxDeleteUser($request, $response, $args)
    {
        $id        = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Users::hasExist($id);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uModel = new \App\Models\Users();
        $uModel->deleteUser($id, $uid);

        return $response->withStatus(200);
    }

    public function ajaxDeleteBulkUsers($request, $response, $args)
    {

        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Users::deleteBulk($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uModel = new \App\Models\Users();
        $users = $pdata["users"];
        foreach ($users as $userId) {
            $uModel->deleteUser($userId, $uid);
        }
        return $response->withStatus(200);
    }

    public function ajaxUsersList($request, $response, $args)
    {
        $pdata    = $request->getParsedBody();
        $uModel   = new \App\Models\Users($this);
        $uid      = $request->getAttribute('uid');

        $result   = $uModel->dataTableList($pdata, $uid);
        return $response->withStatus(200)->withJson($result);
    }


    public function ajaxToggleUserActive($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Users::hasExist($editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uModel = new \App\Models\Users();
        $uModel->toggleActive($editId, $uid);
    }

    public function ajaxResetUserTraffic($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Users::hasExist($editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $uModel = new \App\Models\Users();
        $uModel->resetTraffic($editId, $uid);
    }

    public function ajaxUsersOnlinesList($request, $response, $args)
    {
        $pdata    = $request->getParsedBody();
        $uModel   = new \App\Models\Users($this);
        $uid      = $request->getAttribute('uid');

        $result   = $uModel->dataTableList($pdata, $uid);
        return $response->withStatus(200)->withJson($result);
    }

    public function ajaxKillPidUsers($request, $response, $args)
    {
        $pdata    = $request->getParsedBody();
        if (!empty($pdata["pids"]) && is_array($pdata["pids"])) {
            $pids = $pdata["pids"];
            UserShell::killUsers($pids);
        }
    }

}
