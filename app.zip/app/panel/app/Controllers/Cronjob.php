<?php

/**
 * By ali hassanzadeh
 * Github: https://github.com/ipmartnetwork
 */

namespace App\Controllers;


class Cronjob extends BaseController
{

    public function master($request, $response, $arg)
    {
        $cModel = new \App\Models\Cronjob();
        $cModel->init();

    }
}
